Thanks for your purchase and enjoy!

EXTRA INFO
These pixel images are 400 percent larger than the orignal pixel images. 
To get them into an editable size reduce the images by 25 percent.
When resizing make sure the resample is set to: Nearest Neighbor(hard edges)

For more information contact:
toomaskimsto@gmail.com